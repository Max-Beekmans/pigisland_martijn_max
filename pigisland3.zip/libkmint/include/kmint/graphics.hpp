#ifndef KMINT_GRAPHICS_HPP
#define KMINT_GRAPHICS_HPP

#include "kmint/graphics/color.hpp"
#include "kmint/graphics/image.hpp"

#endif /* KMINT_GRAPHICS_HPP */
