#include "kmint/graph/node.hpp"
#include "gtest/gtest.h"

namespace {} // namespace
